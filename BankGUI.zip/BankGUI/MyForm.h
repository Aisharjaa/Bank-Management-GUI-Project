#pragma once

namespace BankGUI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{

		int pass;
	public:


		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}


		MyForm(String^data)
		{
			InitializeComponent();
		    rtDisplay->Text = data;
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Panel^ panel6;
	private: System::Windows::Forms::Panel^ panel7;
	private: System::Windows::Forms::Button^ Cancel;
	private: System::Windows::Forms::Button^ btnClear;


	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button4;

	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button6;

	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button21;
	private: System::Windows::Forms::Button^ button22;
	private: System::Windows::Forms::Button^ button23;
	private: System::Windows::Forms::Button^ button24;
	private: System::Windows::Forms::Button^ button17;
	private: System::Windows::Forms::Button^ button18;
	private: System::Windows::Forms::Button^ button19;
	private: System::Windows::Forms::Button^ button20;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::RichTextBox^ rtDisplay;
	private: System::Drawing::Printing::PrintDocument^ printDocument1;
	private: System::Windows::Forms::PrintPreviewDialog^ printPreviewDialog1;
	private: System::Windows::Forms::ToolTip^ toolTip1;
	private: System::ComponentModel::IContainer^ components;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->Cancel = (gcnew System::Windows::Forms::Button());
			this->btnClear = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->rtDisplay = (gcnew System::Windows::Forms::RichTextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->printDocument1 = (gcnew System::Drawing::Printing::PrintDocument());
			this->printPreviewDialog1 = (gcnew System::Windows::Forms::PrintPreviewDialog());
			this->toolTip1 = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->panel1->SuspendLayout();
			this->panel5->SuspendLayout();
			this->panel2->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel6->SuspendLayout();
			this->panel7->SuspendLayout();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel1->Controls->Add(this->panel5);
			this->panel1->Controls->Add(this->panel4);
			this->panel1->Controls->Add(this->panel2);
			resources->ApplyResources(this->panel1, L"panel1");
			this->panel1->Name = L"panel1";
			this->panel1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel1_Paint);
			// 
			// panel5
			// 
			this->panel5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel5->Controls->Add(this->button21);
			this->panel5->Controls->Add(this->button22);
			this->panel5->Controls->Add(this->button23);
			this->panel5->Controls->Add(this->button24);
			this->panel5->Controls->Add(this->button17);
			this->panel5->Controls->Add(this->button18);
			this->panel5->Controls->Add(this->button19);
			this->panel5->Controls->Add(this->button20);
			this->panel5->Controls->Add(this->button13);
			this->panel5->Controls->Add(this->button14);
			this->panel5->Controls->Add(this->button15);
			this->panel5->Controls->Add(this->button16);
			this->panel5->Controls->Add(this->Cancel);
			this->panel5->Controls->Add(this->btnClear);
			this->panel5->Controls->Add(this->button11);
			this->panel5->Controls->Add(this->button12);
			resources->ApplyResources(this->panel5, L"panel5");
			this->panel5->Name = L"panel5";
			// 
			// button21
			// 
			resources->ApplyResources(this->button21, L"button21");
			this->button21->Name = L"button21";
			this->button21->UseVisualStyleBackColor = true;
			this->button21->Click += gcnew System::EventHandler(this, &MyForm::button21_Click);
			// 
			// button22
			// 
			resources->ApplyResources(this->button22, L"button22");
			this->button22->Name = L"button22";
			this->button22->UseVisualStyleBackColor = true;
			this->button22->Click += gcnew System::EventHandler(this, &MyForm::button22_Click);
			// 
			// button23
			// 
			resources->ApplyResources(this->button23, L"button23");
			this->button23->Name = L"button23";
			this->button23->UseVisualStyleBackColor = true;
			this->button23->Click += gcnew System::EventHandler(this, &MyForm::button23_Click);
			// 
			// button24
			// 
			resources->ApplyResources(this->button24, L"button24");
			this->button24->Name = L"button24";
			this->button24->UseVisualStyleBackColor = true;
			// 
			// button17
			// 
			resources->ApplyResources(this->button17, L"button17");
			this->button17->Name = L"button17";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm::button17_Click);
			// 
			// button18
			// 
			resources->ApplyResources(this->button18, L"button18");
			this->button18->Name = L"button18";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &MyForm::button18_Click);
			// 
			// button19
			// 
			resources->ApplyResources(this->button19, L"button19");
			this->button19->Name = L"button19";
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &MyForm::button19_Click);
			// 
			// button20
			// 
			resources->ApplyResources(this->button20, L"button20");
			this->button20->Name = L"button20";
			this->button20->UseVisualStyleBackColor = true;
			this->button20->Click += gcnew System::EventHandler(this, &MyForm::button20_Click);
			// 
			// button13
			// 
			resources->ApplyResources(this->button13, L"button13");
			this->button13->Name = L"button13";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm::button13_Click);
			// 
			// button14
			// 
			resources->ApplyResources(this->button14, L"button14");
			this->button14->Name = L"button14";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::button14_Click);
			// 
			// button15
			// 
			resources->ApplyResources(this->button15, L"button15");
			this->button15->Name = L"button15";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm::button15_Click);
			// 
			// button16
			// 
			resources->ApplyResources(this->button16, L"button16");
			this->button16->Name = L"button16";
			this->button16->UseVisualStyleBackColor = true;
			// 
			// Cancel
			// 
			this->Cancel->BackColor = System::Drawing::Color::Red;
			resources->ApplyResources(this->Cancel, L"Cancel");
			this->Cancel->Name = L"Cancel";
			this->Cancel->UseVisualStyleBackColor = false;
			this->Cancel->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// btnClear
			// 
			this->btnClear->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(128)));
			resources->ApplyResources(this->btnClear, L"btnClear");
			this->btnClear->Name = L"btnClear";
			this->btnClear->UseVisualStyleBackColor = false;
			this->btnClear->Click += gcnew System::EventHandler(this, &MyForm::btnClear_Click);
			// 
			// button11
			// 
			resources->ApplyResources(this->button11, L"button11");
			this->button11->Name = L"button11";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button11_Click);
			// 
			// button12
			// 
			resources->ApplyResources(this->button12, L"button12");
			this->button12->Name = L"button12";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &MyForm::button12_Click);
			// 
			// panel4
			// 
			this->panel4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			resources->ApplyResources(this->panel4, L"panel4");
			this->panel4->Name = L"panel4";
			// 
			// panel2
			// 
			this->panel2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel2->Controls->Add(this->button5);
			this->panel2->Controls->Add(this->panel3);
			this->panel2->Controls->Add(this->button6);
			this->panel2->Controls->Add(this->button7);
			resources->ApplyResources(this->panel2, L"panel2");
			this->panel2->Name = L"panel2";
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button5, L"button5");
			this->button5->Name = L"button5";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// panel3
			// 
			this->panel3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel3->Controls->Add(this->button4);
			this->panel3->Controls->Add(this->button2);
			this->panel3->Controls->Add(this->button1);
			this->panel3->Controls->Add(this->panel6);
			resources->ApplyResources(this->panel3, L"panel3");
			this->panel3->Name = L"panel3";
			this->panel3->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &MyForm::panel3_Paint);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button4, L"button4");
			this->button4->Name = L"button4";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button2, L"button2");
			this->button2->Name = L"button2";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button1, L"button1");
			this->button1->Name = L"button1";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// panel6
			// 
			this->panel6->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel6->Controls->Add(this->panel7);
			resources->ApplyResources(this->panel6, L"panel6");
			this->panel6->Name = L"panel6";
			// 
			// panel7
			// 
			this->panel7->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel7->Controls->Add(this->textBox1);
			this->panel7->Controls->Add(this->rtDisplay);
			resources->ApplyResources(this->panel7, L"panel7");
			this->panel7->Name = L"panel7";
			// 
			// textBox1
			// 
			resources->ApplyResources(this->textBox1, L"textBox1");
			this->textBox1->Name = L"textBox1";
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// rtDisplay
			// 
			resources->ApplyResources(this->rtDisplay, L"rtDisplay");
			this->rtDisplay->Name = L"rtDisplay";
			this->rtDisplay->TextChanged += gcnew System::EventHandler(this, &MyForm::rtDisplay_TextChanged);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button6, L"button6");
			this->button6->Name = L"button6";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::Aqua;
			resources->ApplyResources(this->button7, L"button7");
			this->button7->Name = L"button7";
			this->button7->UseVisualStyleBackColor = false;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// printDocument1
			// 
			this->printDocument1->PrintPage += gcnew System::Drawing::Printing::PrintPageEventHandler(this, &MyForm::printDocument1_PrintPage);
			// 
			// printPreviewDialog1
			// 
			resources->ApplyResources(this->printPreviewDialog1, L"printPreviewDialog1");
			this->printPreviewDialog1->Document = this->printDocument1;
			this->printPreviewDialog1->Name = L"printPreviewDialog1";
			// 
			// MyForm
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->Controls->Add(this->panel1);
			this->Name = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->panel1->ResumeLayout(false);
			this->panel5->ResumeLayout(false);
			this->panel2->ResumeLayout(false);
			this->panel3->ResumeLayout(false);
			this->panel6->ResumeLayout(false);
			this->panel7->ResumeLayout(false);
			this->panel7->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {

		Enabblebutton();


	}
	private: System::Void panel3_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	}
	private: System::Void panel1_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
	}
	private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {

		if ((textBox1->Text == "121") || (textBox1->Text == "101") || (textBox1->Text == "222") || (textBox1->Text == "000"))
		{
			pass = int::Parse(textBox1->Text);

			button5->Enabled = true;

			button7->Enabled = true;


			button1->Enabled = true;
			button2->Enabled = true;
			button4->Enabled = true;
			button6->Enabled = true;




			textBox1->Visible = false();

			rtDisplay->AppendText("\t\tWelcome to X Bank\n\n");
			rtDisplay->AppendText("Withdraw" + "\t\t\t" + "Deposit" + "\n\n");
			rtDisplay->AppendText("Cash With Receipt" + "\t\t" + "Balance" + "\n\n");
			rtDisplay->AppendText("Mini Statement" + "\t\t" + "Print Statement" + "\n\n");

		}


		else
		{

			textBox1->Text = "Sorry! Wrong password.";
			textBox1->Focus();


			button5->Enabled = false();

			button7->Enabled = false();


			button1->Enabled = false();
			button2->Enabled = false();
			button4->Enabled = false();
			button6->Enabled = false();


		}


		if ((textBox1->Text != "" && rtDisplay->Text != "")) {

			textBox1->Text = "Cash withdraw successfull";

		}

		

		if ((textBox1->Text != "" && rtDisplay->Text == "Deposit")) {


			rtDisplay->Clear();
		
				rtDisplay->AppendText("Money deposited, please type your pin");
				

				textBox1->Text = "Deposit successfull";

			}
		}










	


	private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {


		System::Windows::Forms::DialogResult iExit;
		iExit = MessageBox::Show("Confirm if you want to cancel", "ATM System", MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (iExit == System::Windows::Forms::DialogResult::Yes)
		{
			Application::Exit();

		}
	}

	private: System::Void Enabblebutton() {

		button5->Enabled = false();

		button7->Enabled = false();


		button1->Enabled = false();
		button2->Enabled = false();
		button4->Enabled = false();
		button6->Enabled = false();


		rtDisplay->Clear();
		textBox1->Text = "";
		textBox1->Visible = true;
		textBox1->Focus();

	}

	private: System::Void Moneybal() {

		if (pass == 121) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 172014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 95000/=" + "\n\n");
		}

		if (pass == 101) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 161014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 50000/=" + "\n\n");
		}

		if (pass == 222) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 181014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 45000/=" + "\n\n");
		}

		if (pass == 000) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 192014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 5000/=" + "\n\n");
		}


	}

	private: System::Void Statement() {

		if (pass == 121) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 172014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 95000/=" + "\n\n");
			rtDisplay->AppendText("Student Loan is " + "\n\n" + "BDT. 500000/=" + "\n\n" + "15% on Interest" + "\n\n" + "Monthly BDT. 8066.75/=");

			rtDisplay->AppendText("Home Rent is " + "\n\n" + "BDT. /=" + "\n\n");
			rtDisplay->AppendText("Mobile No is " + "\n\n" + "01*********" + "\n\n");
		}

		if (pass == 101) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 162014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 90000/=" + "\n\n");
			rtDisplay->AppendText("Student Loan is " + "\n\n" + "BDT. 500000/=" + "\n\n" + "15% on Interest" + "\n\n" + "Monthly BDT. 8066.75/=");

			rtDisplay->AppendText("Home Rent is " + "\n\n" + "BDT. /=" + "\n\n");
			rtDisplay->AppendText("Mobile No is " + "\n\n" + "01*********" + "\n\n");
		}


		if (pass == 222) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 182014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 45000/=" + "\n\n");
			rtDisplay->AppendText("Car Loan is " + "\n\n" + "BDT. 113,434/=" + "\n\n" + "Total Interest Payable BDT. 13,434/=" + "\n\n" + "Monthly Payment BDT. 3,781/=");

			rtDisplay->AppendText("Home Rent is " + "\n\n" + "BDT. /=" + "\n\n");
			rtDisplay->AppendText("Mobile No is " + "\n\n" + "01*********" + "\n\n");
		}

		if (pass == 000) {
			rtDisplay->Clear();
			rtDisplay->AppendText("Account no: 192014014\n\n");
			rtDisplay->AppendText("Balance is " + "\n\n" + "BDT. 5000/=" + "\n\n");
			rtDisplay->AppendText("Student Loan is " + "\n\n" + "BDT. 0/=" + "\n\n");

			rtDisplay->AppendText("Home Rent is " + "\n\n" + "BDT. /=" + "\n\n");
			rtDisplay->AppendText("Mobile No is " + "\n\n" + "01*********" + "\n\n");
		}




	}




	private: System::Void btnClear_Click(System::Object^ sender, System::EventArgs^ e) {


		Enabblebutton();


	}
	private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button21_Click(System::Object^ sender, System::EventArgs^ e) {


		if (textBox1->Text == "") {
			textBox1->Text = "1";
		}
		else
		{
			textBox1->Text = textBox1->Text + 1;
		}
	}
	private: System::Void button17_Click(System::Object^ sender, System::EventArgs^ e) {


		if (textBox1->Text == "") {
			textBox1->Text = "2";
		}
		else
		{
			textBox1->Text = textBox1->Text + 2;
		}
	}
	private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "3";
		}
		else
		{
			textBox1->Text = textBox1->Text + 3;
		}

	}
	private: System::Void button22_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "4";
		}
		else
		{
			textBox1->Text = textBox1->Text + 4;
		}


	}
	private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "5";
		}
		else
		{
			textBox1->Text = textBox1->Text + 5;
		}
	}
	private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "6";
		}
		else
		{
			textBox1->Text = textBox1->Text + 6;
		}
	}
	private: System::Void button23_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "7";
		}
		else
		{
			textBox1->Text = textBox1->Text + 7;
		}
	}
	private: System::Void button19_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "8";
		}
		else
		{
			textBox1->Text = textBox1->Text + 8;
		}
	}
	private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "9";
		}
		else
		{
			textBox1->Text = textBox1->Text + 9;
		}
	}
	private: System::Void button20_Click(System::Object^ sender, System::EventArgs^ e) {

		if (textBox1->Text == "") {
			textBox1->Text = "0";
		}
		else
		{
			textBox1->Text = textBox1->Text + 0;
		}
	}




	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {


		rtDisplay->Clear();
		rtDisplay->AppendText("Deposit");
		
			textBox1->Visible = true;
			textBox1->Clear();

			textBox1->Focus();
			
		


	}
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {


		if ((textBox1->Text == "101")) {
			rtDisplay->Clear();
			rtDisplay->AppendText("\t\tYour previous balance is BDT. 90000/=  \n\n");
			rtDisplay->AppendText("\n\After transaction, your balance");


		}
		else if (textBox1->Text == "121")
		{
			rtDisplay->Clear();
			rtDisplay->AppendText("\t\tYour previous balance is BDT. 95000  \n\n");
			rtDisplay->AppendText("\n\After transaction, your balance");


		}

		else if (textBox1->Text == "222")
		{
			rtDisplay->Clear();
			rtDisplay->AppendText("\t\tYour previous balance is BDT. 45000/=  \n\n");
			rtDisplay->AppendText("\n\After transaction, your balance");

		}

		else if (textBox1->Text == "000") {
			rtDisplay->Clear();
			rtDisplay->AppendText("\t\tYour previous balance is BDT. 5000/  \n\n");
			rtDisplay->AppendText("\n\After transaction, your balance");


		}

	}
	
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {

	Statement();
	printPreviewDialog1->ShowDialog();
}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {

	Statement();
}
private: System::Void printDocument1_PrintPage(System::Object^ sender, System::Drawing::Printing::PrintPageEventArgs^ e) {



	System::Drawing::Font^ fntString = gcnew System::Drawing::Font("Times New Roman", 16, FontStyle::Regular);
	e->Graphics->DrawString(rtDisplay->Text, fntString, Brushes::Black, 100, 100);
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {


	rtDisplay->Clear();
	rtDisplay->AppendText("\t\tWelcome to X Bank\n\n");
	rtDisplay->AppendText("Your Today transaction method and value is\n\n");
	textBox1->Visible = true;
	textBox1->Clear();
	textBox1->Focus();
	printPreviewDialog1->ShowDialog();


}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

	rtDisplay->Clear();
	rtDisplay->AppendText("\t\tWelcome to X Bank\n\n");
	rtDisplay->AppendText("Enter amount below\n\n");
	textBox1->Visible = true;
	textBox1->Clear();
	textBox1->Focus();
}
private: System::Void rtDisplay_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
};
}