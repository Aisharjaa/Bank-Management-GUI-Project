#pragma once
#include "MyForm2.h"





namespace BankGUI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Adminpanel
	/// </summary>
	public ref class Adminpanel : public System::Windows::Forms::Form
	{
	public:
		Adminpanel(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Adminpanel()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;
	protected:
	private: System::Windows::Forms::Button^ button1;

	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::RichTextBox^ rtDisplay;
	private: System::Windows::Forms::RichTextBox^ richTextBox1;
	private: System::Windows::Forms::RichTextBox^ richTextBox2;
	private: System::Windows::Forms::RichTextBox^ richTextBox3;
	private: System::Windows::Forms::RichTextBox^ richTextBox4;
	private: System::Windows::Forms::RichTextBox^ richTextBox5;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::TextBox^ textBox6;
	private: System::Windows::Forms::RichTextBox^ richTextBox6;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button7;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->rtDisplay = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox3 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox4 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox5 = (gcnew System::Windows::Forms::RichTextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->richTextBox6 = (gcnew System::Windows::Forms::RichTextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::Red;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(1008, 78);
			this->panel1->TabIndex = 0;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(12, 113);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(183, 80);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Add Account";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Adminpanel::button1_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(12, 202);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(186, 80);
			this->button3->TabIndex = 3;
			this->button3->Text = L"Update Account";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Adminpanel::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(12, 288);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(183, 75);
			this->button4->TabIndex = 4;
			this->button4->Text = L"Change Pin";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Adminpanel::button4_Click);
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::Red;
			this->panel2->Location = System::Drawing::Point(0, 544);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(1008, 13);
			this->panel2->TabIndex = 1;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(12, 451);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(186, 75);
			this->button5->TabIndex = 5;
			this->button5->Text = L"Exit";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Adminpanel::button5_Click);
			// 
			// rtDisplay
			// 
			this->rtDisplay->Location = System::Drawing::Point(445, 113);
			this->rtDisplay->Name = L"rtDisplay";
			this->rtDisplay->Size = System::Drawing::Size(190, 28);
			this->rtDisplay->TabIndex = 6;
			this->rtDisplay->Text = L"";
			this->rtDisplay->TextChanged += gcnew System::EventHandler(this, &Adminpanel::rtDisplay_TextChanged);
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(445, 212);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(190, 28);
			this->richTextBox1->TabIndex = 7;
			this->richTextBox1->Text = L"";
			// 
			// richTextBox2
			// 
			this->richTextBox2->Location = System::Drawing::Point(445, 154);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->Size = System::Drawing::Size(190, 28);
			this->richTextBox2->TabIndex = 8;
			this->richTextBox2->Text = L"";
			// 
			// richTextBox3
			// 
			this->richTextBox3->Location = System::Drawing::Point(445, 382);
			this->richTextBox3->Name = L"richTextBox3";
			this->richTextBox3->Size = System::Drawing::Size(190, 28);
			this->richTextBox3->TabIndex = 9;
			this->richTextBox3->Text = L"";
			// 
			// richTextBox4
			// 
			this->richTextBox4->Location = System::Drawing::Point(445, 275);
			this->richTextBox4->Name = L"richTextBox4";
			this->richTextBox4->Size = System::Drawing::Size(190, 28);
			this->richTextBox4->TabIndex = 10;
			this->richTextBox4->Text = L"";
			// 
			// richTextBox5
			// 
			this->richTextBox5->Location = System::Drawing::Point(445, 335);
			this->richTextBox5->Name = L"richTextBox5";
			this->richTextBox5->Size = System::Drawing::Size(190, 28);
			this->richTextBox5->TabIndex = 11;
			this->richTextBox5->Text = L"";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(12, 370);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(186, 75);
			this->button2->TabIndex = 12;
			this->button2->Text = L"Account List";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Adminpanel::button2_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(743, 113);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(199, 28);
			this->textBox1->TabIndex = 13;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(743, 382);
			this->textBox2->Multiline = true;
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(199, 28);
			this->textBox2->TabIndex = 14;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(743, 335);
			this->textBox3->Multiline = true;
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(199, 28);
			this->textBox3->TabIndex = 15;
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(743, 269);
			this->textBox4->Multiline = true;
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(199, 28);
			this->textBox4->TabIndex = 16;
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(743, 212);
			this->textBox5->Multiline = true;
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(199, 28);
			this->textBox5->TabIndex = 17;
			this->textBox5->TextChanged += gcnew System::EventHandler(this, &Adminpanel::textBox5_TextChanged);
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(743, 154);
			this->textBox6->Multiline = true;
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(199, 28);
			this->textBox6->TabIndex = 18;
			// 
			// richTextBox6
			// 
			this->richTextBox6->Location = System::Drawing::Point(391, 95);
			this->richTextBox6->Name = L"richTextBox6";
			this->richTextBox6->Size = System::Drawing::Size(572, 369);
			this->richTextBox6->TabIndex = 19;
			this->richTextBox6->Text = L"";
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(837, 475);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(68, 51);
			this->button6->TabIndex = 20;
			this->button6->Text = L"Okay";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Adminpanel::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(533, 470);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(68, 51);
			this->button7->TabIndex = 21;
			this->button7->Text = L"Update Account";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Adminpanel::button7_Click_1);
			// 
			// Adminpanel
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1008, 551);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->textBox6);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->richTextBox5);
			this->Controls->Add(this->richTextBox4);
			this->Controls->Add(this->richTextBox3);
			this->Controls->Add(this->richTextBox2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->rtDisplay);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->richTextBox6);
			this->Name = L"Adminpanel";
			this->Text = L"Adminpanel";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {


		rtDisplay->Clear();
		richTextBox2->Clear();
		richTextBox1->Clear();
		richTextBox4->Clear();
		richTextBox5->Clear();
		richTextBox3->Clear();


		textBox1->Clear();
		textBox2->Clear();
		textBox3->Clear();
		textBox4->Clear();
		textBox5->Clear();
		textBox5->Clear();

		rtDisplay->AppendText("Account No");
		textBox1->AppendText("152014014");
		richTextBox2->AppendText("Name");
		richTextBox1->AppendText("Mobile No");
		richTextBox4->AppendText("Address");
		richTextBox5->AppendText("Deposit Money");
		richTextBox3->AppendText("Pin");





	}
#pragma endregion
	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {

		

		rtDisplay->Clear();
		richTextBox2->Clear();
		richTextBox1->Clear();
		richTextBox4->Clear();
		richTextBox5->Clear();
		richTextBox3->Clear();


		textBox1->Clear();
		textBox2->Clear();
		textBox3->Clear();
		textBox4->Clear();
		textBox5->Clear();
		textBox5->Clear();


		rtDisplay->AppendText("Account No");
		





	}
	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {

		System::Windows::Forms::DialogResult iExit;
		iExit = MessageBox::Show("Do you want to close the application", "Admin Panel", MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (iExit == System::Windows::Forms::DialogResult::Yes)
		{
			

		}


	}
	private: System::Void rtDisplay_TextChanged(System::Object^ sender, System::EventArgs^ e) {



	}
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
		rtDisplay->Clear();
		richTextBox2->Clear();
		richTextBox1->Clear();
		richTextBox4->Clear();
		richTextBox5->Clear();
		richTextBox3->Clear();


		textBox1->Clear();
		textBox2->Clear();
		textBox3->Clear();
		textBox4->Clear();
		textBox5->Clear();
		textBox5->Clear();
		
		
		
		
		rtDisplay->AppendText("Name");
		richTextBox2->AppendText("Account No");
		richTextBox1->AppendText("Mobile No");
		richTextBox4->AppendText("Previous Pin");
		richTextBox5->AppendText("New Pin");
		richTextBox3->AppendText("Confirm Pin");

		
		}


	



	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {

	

		System::Windows::Forms::DialogResult iiExit;
		iiExit = MessageBox::Show("Are you sure", "Admin Confirmation", MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (iiExit == System::Windows::Forms::DialogResult::Yes)
		{
			Application::Exit();

		}





		
		}
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {


		rtDisplay->Clear();
		richTextBox2->Clear();
		richTextBox1->Clear();
		richTextBox4->Clear();
		richTextBox5->Clear();
		richTextBox3->Clear();


		textBox1->Clear();
		textBox2->Clear();
		textBox3->Clear();
		textBox4->Clear();
		textBox5->Clear();
		textBox5->Clear();




		rtDisplay->AppendText("Account No.1");
		richTextBox2->AppendText("Account No.2");
		richTextBox1->AppendText("Account No.3");
		richTextBox4->AppendText("Account No.4");
		richTextBox5->AppendText("Account No.5");
		richTextBox3->AppendText("Account No.6");
		textBox1->AppendText("172014014");
		textBox2->AppendText("192014014");
		textBox3->AppendText("162014014");
		textBox4->AppendText("152014014");
		textBox5->AppendText("142014014");
		textBox6->AppendText("132014014");





	}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {




	



}
private: System::Void button7_Click_1(System::Object^ sender, System::EventArgs^ e) {


	
	richTextBox2->Clear();
	richTextBox1->Clear();
	richTextBox4->Clear();
	richTextBox5->Clear();
	richTextBox3->Clear();


	textBox2->Clear();
	textBox3->Clear();
	textBox4->Clear();
	textBox5->Clear();
	textBox5->Clear();


	if ((textBox1->Text == "172014014") || (textBox1->Text == "162014014") || (textBox1->Text == "182014014") || (textBox1->Text == "192014014") || (textBox1->Text == "152014014") || (textBox1->Text == "142014014") || (textBox1->Text == "132014014") || (textBox1->Text == "122014014"))
	{
		
		richTextBox2->AppendText("Account No");
		richTextBox1->AppendText("Mobile No");
		richTextBox4->AppendText("Address");
		richTextBox5->AppendText("Deposit Money");
		richTextBox3->AppendText("Pin");
	}





}
private: System::Void textBox5_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
};
	}

